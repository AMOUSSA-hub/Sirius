package edu.ezip.ing1.pds.client;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.databind.node.ObjectNode;

import de.vandermeer.asciitable.AsciiTable;
import edu.ezip.commons.LoggingUtils;
import edu.ezip.ing1.pds.business.dto.Student;
import edu.ezip.ing1.pds.business.dto.Students;
import edu.ezip.ing1.pds.client.commons.ClientRequest;
import edu.ezip.ing1.pds.client.commons.ConfigLoader;
import edu.ezip.ing1.pds.client.commons.NetworkConfig;
import edu.ezip.ing1.pds.commons.Request;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.event.Level;
import org.yaml.snakeyaml.Yaml;
import org.yaml.snakeyaml.constructor.Constructor;


import java.io.IOException;
import java.io.InputStream;
import java.sql.SQLException;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.UUID;
import java.io.OutputStream;
import java.net.Socket;
import java.io.ByteArrayOutputStream;
import com.fasterxml.jackson.databind.JsonNode;


public class MainSelectClient {

    private final static String LoggingLabel = "I n s e r t e r - C l i e n t";
    private final static Logger logger = LoggerFactory.getLogger(LoggingLabel);
    private final static String studentsToBeInserted = "students-to-be-inserted.yaml";
    private final static String networkConfigFile = "network.yaml";
    private static final String threadName = "inserter-client";
    private static final String requestOrder = "SELECT_ALL_STUDENTS";
    private static final Deque<ClientRequest> clientRequests = new ArrayDeque<ClientRequest>();
    public static final String ipServeur = "172.31.253.49";
    private static Socket socket;

    public static void main(String[] args) throws IOException, InterruptedException, SQLException {

        final NetworkConfig networkConfig = ConfigLoader.loadConfig(NetworkConfig.class, networkConfigFile);
        networkConfig.setIpaddress("172.31.253.218");
        networkConfig.setTcpport(5432);
        logger.debug("Load Network config file : {}", networkConfig.toString());
        System.out.println(networkConfig.toString());
        int birthdate = 0;
       
        final ObjectMapper objectMapper = new ObjectMapper();
        final String requestId = UUID.randomUUID().toString();
        final Request request = new Request();
        request.setRequestId(requestId);  
        request.setRequestOrder(requestOrder);
        objectMapper.enable(SerializationFeature.WRAP_ROOT_VALUE);
        final byte []  requestBytes = objectMapper.writerWithDefaultPrettyPrinter().writeValueAsBytes(request);
        LoggingUtils.logDataMultiLine(logger, Level.TRACE, requestBytes);
        final SelectAllStudentsClientRequest clientRequest = new SelectAllStudentsClientRequest(
                                                                    networkConfig,
                                                                    birthdate++, request, null, requestBytes);
        clientRequests.push(clientRequest);
        String jsonRequest = objectMapper.writeValueAsString(request);
        
      
        try {
            socket = new Socket(ipServeur, 45065);
            OutputStream outputStream = socket.getOutputStream();
            outputStream.write(jsonRequest.getBytes());
            outputStream.flush(); 
        } catch (IOException e) {
            e.printStackTrace();
        }
    
        
        while (!clientRequests.isEmpty()) {

            final ClientRequest joinedClientRequest = clientRequests.pop();
            //joinedClientRequest.join();

            String res = getReponseServeur(socket);

            ObjectMapper mapper = new ObjectMapper();
            JsonNode responseNode = mapper.readTree(res);
            JsonNode studentsNode = responseNode.get("response_body").get("students");

            System.out.println("Nombre d'etudiants selectionné : " + studentsNode.size() + "\n");
            for (JsonNode studentNode : studentsNode) {
                String studentName = studentNode.get("student_name").asText();
                String studentFirstName = studentNode.get("student_1stname").asText();
                String studentGroup = studentNode.get("student_group").asText();

                System.out.println("Nom de l'étudiant : " + studentName);
                System.out.println("Prénom de l'étudiant : " + studentFirstName);
                System.out.println("Groupe de l'étudiant : " + studentGroup);
                System.out.println(" ");
                
            }


            logger.debug("Thread {} complete.", joinedClientRequest.getThreadName());
        }
    }

    public static String getReponseServeur(Socket socket) {
        try {
            if (socket.isConnected() && !socket.isClosed()) {
                InputStream inputStream = socket.getInputStream();
                ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
                byte[] buffer = new byte[1024];
                int bytesRead;
                while ((bytesRead = inputStream.read(buffer)) != -1) {
                    outputStream.write(buffer, 0, bytesRead);
                }
                String response = outputStream.toString("UTF-8");
                outputStream.close();
                inputStream.close();
                return response;
            } else {
                System.err.println("Le client n'est pas joignable");            
            }
        } catch (IOException e) {
            System.err.println(e);
        }
        return null;
    }
    
}
